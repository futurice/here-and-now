package com.futurice.cascade;

import android.support.annotation.CallSuper;
import android.test.suitebuilder.annotation.LargeTest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class AsyncBuilderTest extends AsyncAndroidTestCase {

    @Before
    @CallSuper
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testIsInitialized() throws Exception {

    }

    @Test
    public void testGetWorkerThreadType() throws Exception {

    }

    @Test
    public void testGetSerialWorkerThreadType() throws Exception {

    }

    @Test
    public void testSetWorkerThreadType() throws Exception {

    }

    @Test
    public void testSetSerialWorkerThreadType() throws Exception {

    }

    @Test
    public void testGetUiThreadType() throws Exception {

    }

    @Test
    public void testSetUIThreadType() throws Exception {

    }

    @Test
    public void testGetNetReadThreadType() throws Exception {

    }

    @Test
    public void testSetNetReadThreadType() throws Exception {

    }

    @Test
    public void testGetNetWriteThreadType() throws Exception {

    }

    @Test
    public void testSetNetWriteThreadType() throws Exception {

    }

    @Test
    public void testGetFileThreadType() throws Exception {

    }

    @Test
    public void testSetFileThreadType() throws Exception {

    }

    @Test
    public void testSetFileWriteThreadType() throws Exception {

    }

    @Test
    public void testGetFileService() throws Exception {

    }

    @Test
    public void testSetFileService() throws Exception {

    }

    @Test
    public void testGetWorkerExecutorService() throws Exception {

    }

    @Test
    public void testGetSerialWorkerExecutorService() throws Exception {

    }

    @Test
    public void testSetWorkerQueue() throws Exception {

    }

    @Test
    public void testSetSerialWorkerQueue() throws Exception {

    }

    @Test
    public void testGetWorkerQueue() throws Exception {

    }

    @Test
    public void testGetSerialWorkerQueue() throws Exception {

    }

    @Test
    public void testSetFileQueue() throws Exception {

    }

    @Test
    public void testGetFileQueue() throws Exception {

    }

    @Test
    public void testSetNetReadQueue() throws Exception {

    }

    @Test
    public void testSetNetWriteQueue() throws Exception {

    }

    @Test
    public void testGetNetReadQueue() throws Exception {

    }

    @Test
    public void testGetNetWriteQueue() throws Exception {

    }

    @Test
    public void testGetFileExecutorService() throws Exception {

    }

    @Test
    public void testGetNetReadExecutorService() throws Exception {

    }

    @Test
    public void testGetNetWriteExecutorService() throws Exception {

    }

    @Test
    public void testGetUiExecutorService() throws Exception {

    }

    @Test
    public void testSetUiExecutorService() throws Exception {

    }

    @Test
    public void testGetNetAbstractRESTService() throws Exception {

    }

    @Test
    public void testSetNetAbstractRESTService() throws Exception {

    }

    @Test
    public void testSetWorkerExecutorService() throws Exception {

    }

    @Test
    public void testSetSerialWorkerExecutorService() throws Exception {

    }

    @Test
    public void testSingleThreadedWorkerExecutorService() throws Exception {

    }

    @Test
    public void testSetFileReadExecutorService() throws Exception {

    }

    @Test
    public void testSetFileWriteExecutorService() throws Exception {

    }

    @Test
    public void testSetNetReadExecutorService() throws Exception {

    }

    @Test
    public void testSetNetWriteExecutorService() throws Exception {

    }

    @Test
    public void testSetUI_Thread() throws Exception {

    }

    @Test
    public void testSetFailFast() throws Exception {

    }

    @Test
    public void testSetShowErrorStackTraces() throws Exception {

    }

    @Test
    public void testBuild() throws Exception {

    }
}