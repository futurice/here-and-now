package com.futurice.cascade.reactive.ui;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class AltArrayAdapterTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testCreateFromResource() throws Exception {

    }

    @Test
    public void testAddAsync() throws Exception {

    }

    @Test
    public void testInsertAsync() throws Exception {

    }

    @Test
    public void testRemoveAsync() throws Exception {

    }

    @Test
    public void testSortAsync() throws Exception {

    }

    @Test
    public void testNotifyDataSetChangedAsync() throws Exception {

    }

    @Test
    public void testNotifyDataSetInvalidatedAsync() throws Exception {

    }

    @Test
    public void testSetNotifyOnChangeAsync() throws Exception {

    }

    @Test
    public void testAddAllAsync() throws Exception {

    }

    @Test
    public void testAddAllAsync1() throws Exception {

    }

    @Test
    public void testClearAsync() throws Exception {

    }

    @Test
    public void testGetCountAsync() throws Exception {

    }

    @Test
    public void testGetItemAsync() throws Exception {

    }

    @Test
    public void testGetPositionAsync() throws Exception {

    }

    @Test
    public void testGetFilterAsync() throws Exception {

    }

    @Test
    public void testGetItemIdAsync() throws Exception {

    }

    @Test
    public void testSetDropDownViewResourceAsync() throws Exception {

    }

    @Test
    public void testGetViewAsync() throws Exception {

    }

    @Test
    public void testGetDropDownViewAsync() throws Exception {

    }

    @Test
    public void testIsEmptyAsync() throws Exception {

    }
}