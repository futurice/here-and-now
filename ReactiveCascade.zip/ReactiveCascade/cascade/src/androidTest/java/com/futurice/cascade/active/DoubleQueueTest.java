package com.futurice.cascade.active;

import android.support.annotation.CallSuper;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 6/4/2015.
 */
@SmallTest
public class DoubleQueueTest extends AsyncAndroidTestCase {

    @Before
    @CallSuper
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testPeek() throws Exception {

    }

    @Test
    public void testPoll() throws Exception {

    }

    @Test
    public void testPoll1() throws Exception {

    }

    @Test
    public void testRemove() throws Exception {

    }

    @Test
    public void testPut() throws Exception {

    }

    @Test
    public void testTake() throws Exception {

    }
}