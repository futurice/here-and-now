package com.futurice.cascade.util;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@SmallTest
public class AltWeakReferenceTest extends AsyncAndroidTestCase {

    @Test
    public void testEquals() throws Exception {

    }
}