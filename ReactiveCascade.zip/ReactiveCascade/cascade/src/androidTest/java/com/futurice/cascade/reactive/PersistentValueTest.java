package com.futurice.cascade.reactive;

import android.support.annotation.CallSuper;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class PersistentValueTest extends AsyncAndroidTestCase {

    @Before
    @CallSuper
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetPersistentValue() throws Exception {

    }

    @Test
    public void testGetPersistentValue1() throws Exception {

    }

    @Test
    public void testGetPersistentValue2() throws Exception {

    }

    @Test
    public void testOnSharedPreferenceChanged() throws Exception {

    }

    @Test
    public void testSet() throws Exception {

    }
}