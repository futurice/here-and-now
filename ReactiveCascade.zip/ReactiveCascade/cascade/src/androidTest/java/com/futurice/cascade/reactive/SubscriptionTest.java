package com.futurice.cascade.reactive;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class SubscriptionTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetName() throws Exception {

    }

    @Test
    public void testSubscribeSource() throws Exception {

    }

    @Test
    public void testUnsubscribeSource() throws Exception {

    }

    @Test
    public void testSearchReactiveTargets() throws Exception {

    }

    @Test
    public void testFire() throws Exception {

    }

    @Test
    public void testFireNext() throws Exception {

    }

    @Test
    public void testUnsubscribe() throws Exception {

    }

    @Test
    public void testUnsubscribeAllSources() throws Exception {

    }

    @Test
    public void testUnsubscribeAll() throws Exception {

    }

    @Test
    public void testSplit() throws Exception {

    }

    @Test
    public void testSubscribe() throws Exception {

    }

    @Test
    public void testSubscribe1() throws Exception {

    }

    @Test
    public void testSubscribe2() throws Exception {

    }

    @Test
    public void testSubscribe3() throws Exception {

    }

    @Test
    public void testSubscribeMap() throws Exception {

    }

    @Test
    public void testSubscribeMap1() throws Exception {

    }

    @Test
    public void testSubscribe4() throws Exception {

    }

    @Test
    public void testSubscribe5() throws Exception {

    }

    @Test
    public void testSubscribe6() throws Exception {

    }
}