package com.futurice.cascade.util;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class DefaultThreadTypeTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testExecute() throws Exception {

    }

    @Test
    public void testExecuteNext() throws Exception {

    }

    @Test
    public void testIsInOrderExecutor() throws Exception {

    }
}