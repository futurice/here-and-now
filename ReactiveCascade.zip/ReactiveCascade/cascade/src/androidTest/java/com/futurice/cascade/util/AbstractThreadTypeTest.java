package com.futurice.cascade.util;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class AbstractThreadTypeTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testExecute() throws Exception {

    }

    @Test
    public void testWrapRunnableAsErrorProtection() throws Exception {

    }

    @Test
    public void testWrapRunnableAsErrorProtection1() throws Exception {

    }

    @Test
    public void testExecute1() throws Exception {

    }

    @Test
    public void testExecute2() throws Exception {

    }

    @Test
    public void testExecuteNext() throws Exception {

    }

    @Test
    public void testMoveToHeadOfQueue() throws Exception {

    }

    @Test
    public void testExecuteNext1() throws Exception {

    }

    @Test
    public void testThen() throws Exception {

    }

    @Test
    public void testThen1() throws Exception {

    }

    @Test
    public void testMap() throws Exception {

    }

    @Test
    public void testThen2() throws Exception {

    }

    @Test
    public void testFrom() throws Exception {

    }

    @Test
    public void testThen3() throws Exception {

    }

    @Test
    public void testThen4() throws Exception {

    }

    @Test
    public void testMap1() throws Exception {

    }

    @Test
    public void testFork() throws Exception {

    }

    @Test
    public void testShutdown() throws Exception {

    }

    @Test
    public void testShutdownNow() throws Exception {

    }

    @Test
    public void testGetName() throws Exception {

    }
}