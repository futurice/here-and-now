package com.futurice.cascade.reactive.ui;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class ReactiveTextViewTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetName() throws Exception {

    }

    @Test
    public void testOnDetachedFromWindow() throws Exception {

    }

    @Test
    public void testOnAttachedToWindow() throws Exception {

    }

    @Test
    public void testSetReactiveValue() throws Exception {

    }

    @Test
    public void testGetReactiveValue() throws Exception {

    }
}