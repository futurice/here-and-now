package com.futurice.cascade.active;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 6/4/2015.
 */
@LargeTest
public class AltFutureTest extends AsyncAndroidTestCase {

    @Test
    public void testCancel() throws Exception {

    }

    @Test
    public void testRun() throws Exception {

    }

    @Test
    public void testDoFork() throws Exception {

    }
}