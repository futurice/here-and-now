package com.futurice.cascade.active;

import android.support.annotation.CallSuper;
import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.SmallTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 6/4/2015.
 */
@SmallTest
public class ImmutableValueTest extends AsyncAndroidTestCase {

    @Before
    @CallSuper
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testThen() throws Exception {

    }

    @Test
    public void testThen1() throws Exception {

    }

    @Test
    public void testIsSet() throws Exception {

    }

    @Test
    public void testGet() throws Exception {

    }

    @Test
    public void testSafeGet() throws Exception {

    }

    @Test
    public void testSet() throws Exception {

    }

    @Test
    public void testToString() throws Exception {

    }

    @Test
    public void testGetName() throws Exception {

    }
}