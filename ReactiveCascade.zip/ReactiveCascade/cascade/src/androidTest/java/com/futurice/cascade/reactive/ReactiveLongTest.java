package com.futurice.cascade.reactive;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class ReactiveLongTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testAddAndGet() throws Exception {

    }

    @Test
    public void testMultiplyAndGet() throws Exception {

    }

    @Test
    public void testIncrementAndGet() throws Exception {

    }

    @Test
    public void testDecrementAndGet() throws Exception {

    }
}