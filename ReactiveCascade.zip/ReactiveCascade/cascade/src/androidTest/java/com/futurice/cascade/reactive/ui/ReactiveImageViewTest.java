package com.futurice.cascade.reactive.ui;

import android.support.test.runner.AndroidJUnit4;
import android.test.suitebuilder.annotation.LargeTest;

import com.futurice.cascade.AsyncAndroidTestCase;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by phou on 04-06-2015.
 */
@LargeTest
public class ReactiveImageViewTest extends AsyncAndroidTestCase {

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testFire() throws Exception {

    }

    @Test
    public void testFireNext() throws Exception {

    }

    @Test
    public void testSetImageURI() throws Exception {

    }

    @Test
    public void testSubscribeSource() throws Exception {

    }

    @Test
    public void testUnsubscribeSource() throws Exception {

    }

    @Test
    public void testUnsubscribeAllSources() throws Exception {

    }

    @Test
    public void testGetName() throws Exception {

    }

    @Test
    public void testOnDetachedFromWindow() throws Exception {

    }
}